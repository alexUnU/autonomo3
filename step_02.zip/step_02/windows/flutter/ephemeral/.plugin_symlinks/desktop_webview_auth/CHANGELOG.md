# 0.0.15

- fix: Google Sign in exiting early, updated OAuth path

# 0.0.14

- fix: Deprecated package tag in AndroidManifest.xml

# 0.0.13

- Chore: Upgrade dependencies

# 0.0.12

- Fix: Add support to AGP 8.0.

# 0.0.11

- Fix: return nil instead of FlutterErrorNotImplemented on iOS

## 0.0.10

- Fix: add stub implementations for android, ios and web

## 0.0.9

- Fix: possible dependency conflict on Windows with other plugins using WebView2.

## 0.0.8

- Feat: GitHub authorization flow on Windows, Linux and macOS.

## 0.0.7

- Fix: Windows WebView Google sign-in issue.
- Fix: Google scopes query encoding.

## 0.0.6

- Feat: Windows support.

## 0.0.5

- Fix: issue with `signIn` future.

## 0.0.4

- Feat: Handle id_token responseType for Google provider.
- Feat: Default Google responseType to token id_token

## 0.0.3

- Feat: linux webview support.
- Feat: support custom webview width and height.
- Feat: Recaptcha verification.

## 0.0.2

- Fix: remove 'Untitled' window title.

## 0.0.1

- Initial release.
