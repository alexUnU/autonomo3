void main() {
  // TODO(@lesnitsky): figure out testing approach
}
