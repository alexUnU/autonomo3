abstract class JsonSerializable {
  Future<Map<String, dynamic>> toJson();
}
